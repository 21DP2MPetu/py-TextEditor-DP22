
import tkinter as tk
import MainGUI

root = tk.Tk()
window = MainGUI.GUI(root)
root.mainloop()