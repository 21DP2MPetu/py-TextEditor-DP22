# py-TextEditor-DP22
Teksta Rediģēšanas Porgramma.
# Teksta rediģēšanas projekts.
Autori: Roberts Juris Sirmais, Maksims Petunovs, Daniels Smirnovs
# Teksta rediģēšanas programmas izveides posms

1. Savākt nepieciešamo informāciju jeb plāna izveidošana
2. Pirmais programmēšanas posms: teksta rediģēšanas programmas koda rakstīšana + testi/izmēģinājumi.
3. Kad pamati ir uzrakstīti tad sākas testēšanas, kommandas kolēģi izmēģina programmu(testē programmas kodu). Nepieciešamības gadījumā veikt labojumus vai papildinājumus.
4. Turpināt testēt un papildus veidot programmu tālāk.
5. Tad programmu pilnīgi izmēģināt UN Ja testi/izmēģinājumi ir veiksmīgi tad domāt ko darīt tālāk.
iespējamās funkcijas ko var pievienot Teksta Rediģēšanas programmā:
  - Kalkulators
  -
  ...
  
6. Pilnveidot programmu.
