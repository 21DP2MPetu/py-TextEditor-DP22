
import texteditor as t

t.TextEditor.ShowWindow()